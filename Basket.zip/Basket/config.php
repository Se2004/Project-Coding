<?php
$dbhost = "localhost";
$dbuser = "";
$dbpassword = "";
$dbdatabase = "";
$config_basedir = "http://YOUR WEB SITE/";
$config_sitename = "Demo Basket";
$db = mysql_connect($dbhost, $dbuser, $dbpassword) or die(mysql_error());
mysql_select_db($dbdatabase, $db) or die(mysql_error());
?>